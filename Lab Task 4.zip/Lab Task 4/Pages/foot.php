    <footer class="footer-part">
        <div class="footer-container">
            <p>Copyright &copy; 2022</p>
        </div>
    </footer>

</body>
</html>
