<?php require("head.php"); ?>

<h1 class="my-content">Welcome to Online Health Service</h1>

<?php require("foot.php"); ?>
