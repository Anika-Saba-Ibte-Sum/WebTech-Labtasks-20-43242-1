<?php 
require_once 'db_connect.php';
function addappointment($data){
     $conn = db_conn();
     $selectQuery = "INSERT INTO `appointment`(`doctor_name`, `date`, `time`) VALUES (:name, :date, :time)";
    try{
        $stmt = $conn->prepare($selectQuery);
        $stmt->execute([
          ':doctor_name' => $data['name'],
          ':username' => $data['username'],
          ':password' => $data['password'],
          ':date' => $data['date'],
          ':time' => $data['time']
        ]);
    }catch(PDOException $e){
        echo $e->getMessage();
    }

    
    $conn = null;
    return true;
}
?>
