<?php
 //session_start(); 
require("../Model/Appointment-model.php");
$_SESSION["nameErr"] = $_SESSION["dateErr"]=$_SESSION["timeErr"]="";
$nameErr  = $dateErr = $timeErr = "";
$name = $date = $time =  "";

if(isset($_POST["submit"]))  
{  
  $err = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
  if (empty($_POST["name"])) {
    $nameErr = "* Name is required";
     $err = true;
  } 
  else {
    $name = $_POST["name"];
   
  }


  if(empty($_POST["time"])){
     $timeErr = "* Time is required";
     $err = true;
     }
     else{   
        $time = $_POST["time"];
     }

  if (empty($_POST["date"])) {
    $dateErr = "* Date  is required";
     $err = true;
  } else {
    $day = $_POST["date"];
 
    }
  }

  if(!$err){
  $data['name'] = $_POST['name'];
  $data['date'] = $_POST['date'];
  $data['username'] = $_POST['username']; 
  $data['password'] = password_hash($_POST['pass'], PASSWORD_BCRYPT, ["cost"=>12]);
  $data['time'] = $_POST['time'];

    if (addappointment($data)) {

    echo 'Appointment is taken successfully';
    header("location: ../View/Login.php");
  } 
}
   
 else
   {
    $_SESSION["nameErr"]=$nameErr;
    $_SESSION["unameErr"]=$unameErr;
    $_SESSION["dateErr"]=$dateErr;
    $_SESSION["passErr"]=$timeErr;

    header("location: ../View/Appointment.php");
   }
  }


 ?> 