<?php require("head.php"); 
require("../Controller/Appointment-control.php"); 
if(!isset($_SESSION["username"])){
        header("location: Login.php");
    }
?>

 
<div class="container custom-form-dashboard">
  <div class="navitems">
    <table style="width: 100%;">
       <tr style="width: 100%;">

              <td style="width: 20%;">
         <ul id="list-of-url">

            <li>User Account</li>
            <hr>
                    <li><a href="../ViewView/Dasboard.php">Dashboard</a></li>
                    <li><a href="../View/View Profile.php">View Profile</a></li>
                    <li><a href="../View/Edit Profile.php">Edit Profile</a></li>
                    <li><a href="../View/Change Profile Picture.php">Change Profile Picture</a></li>
                    <li><a href="../View/Change Password.php">Change Password</a></li>
                    <li><a href="../View/Doctors List.php">Doctor's List</a></li>
                    <li><a href="../View/Appointment.php">Appointment</a></li>
                    <li><a href="../View/Show-Appointment.php">Show Appointment</a></li>
                    <li><a href="../View/Prescription.php">Prescription</a></li>
                    <li><a href="../View/Payment.php">Payment</a></li>
                </ul>
               </td>
               <td style="width: 70%;">
                 <div class="container custom-form" style="width:500px;">  
                                
                <form method="post" action="Appointment.php">  
                      
                     <br>  
                     <fieldset>
                         <legend>FOR APPOINTMENT</legend>
                         <br> <br> 
                         <fieldset>
                              <legend>Doctor Name</legend> 
                              
                                <select name="dname" id="dname">
                                <option value="">Select a doctor</option>
                                <option value="anika15">Anika Saba Ibte Sum</option>
                                <option value="yeasir67 ">Md. Yeasir Hossain</option>
                                <option value="pranto45">Zuhare Pranto</option>
                                <option value="ovi90">Md. Washim Akram</option>
                                <option value="safrin12">Sadia Afrin</option>
                                <option value="nafis67">Nafis Siddique</option>
                                <option value="abir234">Faisal Abir</option>
                                <option value="nasrin12">Nasrin Akter</option>
                                <option value="laboni34">Laboni Sarkar</option>
                                <option value="talha1234">Talha Obaid</option>
                                <span class="red">&nbsp;<?php if(isset($_SESSION["nameErr"])){echo $_SESSION["nameErr"]; $_SESSION["nameErr"] = "";} ?></span>
                                </select> 
                         </fieldset>
                         <hr>
                          <fieldset>
                               <legend>Date</legend>
                               <select name="spl" id="spl">
                                  <option value="">Select Date</option>
                                  <option value="4/16/2022">4/16/2022</option>
                                  <option value="4/17/2022">4/17/2022</option>
                                  <option value="4/18/2022">4/18/2022</option>
                                  <option value="4/19/2022">4/19/2022</option>
                                  <option value="4/20/2022">4/20/2022</option>
                                  <option value="4/21/2022">4/21/2022</option>
                                  <option value="4/22/2022">4/22/2022</option>
                                  <option value="4/23/2022">4/23/2022</option>
                                  <option value="4/24/2022">4/24/2022</option>
                                  <option value="4/25/2022">4/25/2022</option>
                                  <span class="red">&nbsp;<?php if(isset($_SESSION["dateErr"])){echo $_SESSION["dateErr"]; $_SESSION["dateErr"] = "";} ?></span>
                                </select> 
                          </fieldset>
                          <hr>
                         <fieldset>
                              <legend>Select Time</legend>
                              <select name="st" id="st">
                                  <option value="">Select Time</option>
                                  <option value="4.00pm">4.00pm</option>
                                  <option value="7.00pm">5.00pm</option>
                                  <option value="5.00pm">6.00pm</option>
                                  <option value="6.00pm">7.00pm</option>
                                  <option value="4.00pm">8.00pm</option>
                                  <span class="red">&nbsp;<?php if(isset($_SESSION["timeErr"])){echo $_SESSION["timeErr"]; $_SESSION["timeErr"] = "";} ?></span>
                                </select> 
                         </fieldset>
                         <hr>
                         
                          <input type="submit" onclick='alert("Appointment is taken successfully!");' name="Appointment" value="Appointment" class="btn btn-info" />
                          <input type="submit" name="Cancel Appointment" value="Cancel Appointment" class="btn btn-info" /><br />                      
                          
                           
                          </fieldset>
                          <hr> 
                     
                </form>  
           </div>  
                    

               </td>
             </tr>
            
    </table>            
    </div>
</div>


<?php include("foot.php"); ?>