    <footer class="footer-part">
        <div class="footer-container">
            <p>Copyright &copy; 2022</p>
        </div>
    </footer>
<script type="text/javascript" src="/Final Project/Online Health Service/JS/jquery-1.12.4.min.js"></script>
<script type="text/javascript" src="/Final Project/Online Health Service/JS/all.min.js"></script>
<script type="text/javascript" src="/Final Project/Online Health Service/JS/bootstrap.bundle.min.js"></script>

<script type="text/javascript" src="/Final Project/Online Health Service/JS/script.js"></script>
</body>
</html>
