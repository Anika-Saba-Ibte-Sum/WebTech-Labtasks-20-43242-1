<?php require("head.php"); 
require("../Controller/Payment-control.php"); 
if(!isset($_SESSION["username"])){
        header("location: Login.php");
    }
?>

<div class="container custom-form-doctorlist">
  <div class="navitems">
    <table style="width: 100%;">
       <tr style="width: 100%;">

              <td style="width: 20%;">
         <ul id="list-of-url">

            <li>User Account</li>
            <hr>
                    <li><a href="../View/Dasboard.php">Dashboard</a></li>
                    <li><a href="../View/View Profile.php">View Profile</a></li>
                    <li><a href="../View/Edit Profile.php">Edit Profile</a></li>
                    <li><a href="../View/Change Profile Picture.php">Change Profile Picture</a></li>
                    <li><a href="../View/Change Password.php">Change Password</a></li>
                    <li><a href="../View/Doctors List.php">Doctor's List</a></li>
                    <li><a href="../View/Appointment.php">Appointment</a></li>
                    <li><a href="../View/Show-Appointment.php">Show Appointment</a></li>
                    <li><a href="../View/Prescription.php">Prescription</a></li>
                    <li><a href="../View/Payment.php">Payment</a></li>
                </ul>
               </td>
               <td style="width: 70%;">
                <div class="container custom-form" style="width:500px;">  
                                
                <form method="post">  
                      
                     <br>  
                     <fieldset>
                         <legend>FOR ONLINE PAYMENT</legend>
                         <br> <br> 
                         <fieldset>
                            
                            <select name="payment" id="payment">
                                <option value="">Select payment</option>
                                <option value="anika15">bKash</option>
                                <option value="yeasir67 ">Nagad</option>
                                <option value="pranto45">Rocket</option>
                            </select>

                         </fieldset>
                         <br>
                         <hr>
                         <fieldset>
                               <legend>Mobile Number</legend>
                               <input type="text" name = "mobile" class="form-control"/>
                          </fieldset>
                          <hr>
                          <fieldset>
                               <legend>Amount</legend>
                               <input type="text" name = "amnt" class="form-control"/>
                          </fieldset>
                          <hr>
                         <fieldset>
                              <legend>Pin Number</legend>
                              <input type="pin" name = "pin" class="form-control" />
                         </fieldset>
                         <hr>
                        
                        
                          </fieldset>
                          <input type="submit" name="submit" value="Submit" class="btn btn-info" onclick="myFunction()"/>
                          <input type="reset" name="reset" value="Reset" class="btn btn-info" /><br />
                                          
                          <?php  
                          if(isset($message))  
                          {  
                               echo $message;  
                          }  
                          
                          ?> 
                           
                          </fieldset>
 
                     
                </form>  
           </div>  
               </td>
             </tr>
            
    </table>            
    </div>
</div>
<!-- <?php
            if(isset($_POST["submit"]))  
  {?> -->

                <script>
                   function myFunction() {
                        alert("Payment is done successfully!");
}             
                </script>
            <?php }
                ?>

<?php include("foot.php"); ?>