<?php require("head.php");  
if(!isset($_SESSION["username"])){
        header("location: Login.php");
    }
?>

<div class="container custom-form-dashboard">
  <div class="navitems">
    <table style="width: 100%;">
       <tr style="width: 100%;">

              <td style="width: 20%;">
         <ul id="list-of-url">

            <li style="padding: 180px;">User Account</li>
            <hr>
                    <li><a href="../View/Dasboard.php">Dashboard</a></li>
                    <li><a href="../View/View Profile.php">View Profile</a></li>
                    <li><a href="../View/Edit Profile.php">Edit Profile</a></li>
                    <li><a href="../View/Change Profile Picture.php">Change Profile Picture</a></li>
                    <li><a href="../View/Change Password.php">Change Password</a></li>
                    <li><a href="../View/Doctors List.php">Doctor's List</a></li>
                    <li><a href="../View/Appointment.php">Appointment</a></li>
                    <li><a href="../View/Show-Appointment.php">Show Appointment</a></li>
                    <li><a href="../View/Prescription.php">Prescription</a></li>
                    <li><a href="../View/Payment.php">Payment</a></li>
                </ul>
               </td>
               <td class="DoctorList" style="width: 70%; position: relative;">
                <table style="display: block; position: absolute; left: 50%; transform: translateX(-50%);">
                
              <br><br>
              <h5>Appointment's Details</h5>
              <table style="display: block; position: absolute; left: 50%; transform: translateX(-50%);">
  
                <tr>

                <th>Doctor's Name</th>

                <th>Date</th>

                <th>Time</th>

            </tr>

            <tr>

                <td><?php echo "Md. Washim Akram"; ?></td>

                <td><?php echo "4/18/2000" ; ?></td>

                <td><?php echo "4.00pm" ; ?></td>


            </tr>
            </table>

                <p style="display: block; position: absolute; left: 50%; transform: translateX(-50%);" id="txtHint"></p>
                </table>
                
               </td>
             </tr>
            
    </table>            
    </div>
</div>
<script>
  
function showdoctor(str) {
  if (str == "") {
    document.getElementById("txtHint").innerHTML = "";
    return;
  }
  const xhttp = new XMLHttpRequest();
  xhttp.onload = function() {
    document.getElementById("txtHint").innerHTML = this.responseText;
  }
  xhttp.open("GET", "../Controller/Doctor-control.php?q="+str);
  xhttp.send();
}
</script>
<?php require("foot.php"); ?>